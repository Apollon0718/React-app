import React from 'react';

import './QuizResults.css';
import ResultAnswer from './ResultAnswer.js';

const QuizResults = (props) => {
        const answersList = props.userAnswers.map( (answer, index) => {
            const question = props.questions[index];
            const rightAnswer = props.rightAnswers[index];
            const solution = props.solutions[index];
            // console.log(solution,'index')
            return <ResultAnswer key={index} index={index} question={question} answer={answer} rightAnswer={rightAnswer} solution={solution} />
            }
        );

        return(
            <div className="results-container">
                <h1>Summary</h1>
                <ul>
                    <li>
                    <h4 opacity='0'>No.</h4>
                    <div className="answer">
                        <button className="userAnswerSkipped tableheadings">Your Answer</button>
                    </div>
                    <div className="answer">
                        <button className="userAnswerSkipped tableheadings">Correct Answer</button> 
                    </div>
                    <div className="answer">
                        <button className="userAnswerSkipped tableheadings">solution</button> 
                    </div>
                    </li>
                {answersList}</ul>
            </div>
        );
}

export default QuizResults;
