import React from 'react'
// import ElapsedTime from './elapsed-time/index'
// import Buttons from './buttons/index'

// import './styles.css'

class Timer extends React.Component {
    constructor(props){
        super(props) 
            
        this.state = {
            timerStarted: false,
            timerStopped: true,
            minutes: 0,
            seconds: 0,
            captures: []
        }
    }

    render() {
        //const {count} = this.state
        
        return (
            <div classname='container'>
                <h1>{this.state.minutes + ":" + this.state.seconds}</h1>
            </div>
        )
    }

    componentDidMount () {
        this.myIntreval = setInterval(()=>{
            if (this.state.seconds>=59){
                this.setState((prevState)=>({minutes: prevState.minutes+1,seconds: -1}));
            }
            this.setState(prevState => ({
                seconds: prevState.seconds + 1
            }))
        }, 1000)
    }
} 

export default Timer