// import React from 'react'

// function elapsedTime() {
//     return '00:00'
// }

// export default function elapsedTime(props){
//     return (
//         <div classmate='elapsed-time'>
//             {elapsedTime()}
//         </div>
//     )
// }