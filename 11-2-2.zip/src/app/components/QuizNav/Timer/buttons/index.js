// import React from 'react'

// export default function Buttons(props){
//     return (
//         <div className='buttons'>
//             <button>
//                 Start
//             </button>
//         </div>
//     )
// }